# CXP Developer Essentials Frontend

## Module 02 - Exercise 01: Structured Content

The objective of this exercise is to create reusable content by using Structured Content Type. We will also create a template and use it to render the Structured Content Item.

![](images/screenshot.png)

### 1. Create Structured Content Type

We are going to create a Structured Content Type - Credit Card

- Copy the folder ***structured-content-type-training-credit-card*** from assets folder provided in repository to ***statics/prebuilt*** in your solution.

- Open ***structured-content-type-training-credit-card/creditcard.json*** and add improvements for following:

- Refer the [JSON Schema Documentation](https://my.backbase.com/docs/product-documentation/documentation//portal/latest/structcontent_jsonschema.html) to know more about metadata.

- Use properties to add placeholder text for various fields and customize the tooltip help text.

- Add field for image fields so that CXP Manager displays image input box for these.

### 2. Create an item from the created Type

- Open Portal Content and create an item for the new Structured Content Type.

### 3. Create the template to render Structured Content Type

We are now going to create a Template for  that can render Credit Card Items.

- Copy the folder ***feature-training-structured-content-templates*** from assets folder provided in repository to ***statics/prebuilt*** in your solution.

- Refer the [Template Documentation](https://my.backbase.com/docs/product-documentation/documentation//portal/latest/structcontent_template.html) to know about how to access properties from JSON Schema to Template.

- Open ***templates/CreditCard.html*** and add data properties.

***Note:***
You may use images from images folder for banner and credit card.

### 4. Add styles to the template

- Copy the file ***_credit-card-detail.scss*** from ***assets/styles*** folder to custom theme folder.

- Import the file's dependencies such that it is included in theme.

---

[< Back to exercises index](https://bitbucket.org/backbase/cxp-fe2-m00-training-overview)