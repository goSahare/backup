# CXP Developer Essentials Frontend

## Module 01 - Exercise 06 : Working with RAML

In this exercise, you will learn how to develop a Custom Widget that gets data from a Mock Data Module. More specifically, you will:

* Generate Custom Widget with Extension and Model
* Generate Data Modules from provided RAML files
* Implement the view to display data
* Apply Bootstrap classes to style the view

![](images/diagram.png)

## Instructions

### Generating the Custom Widget

You will create an Appointments Widget using bb-cli. For this exercise, the Appointments widget will require both Extension and Model.  
The widget must be called **widget-training-appointments-ng**, and when prompted for the Backbase version you're using, you must choose the appropriate version, for example: **Backbase 5.X**  

### Generating the Data Modules using RAML

1. Download the provided RAML files for the Appointments Widget from the "RAML" folder
2. Use bb-convert to generate the Mock Data Modules (https://www.npmjs.com/package/@bb-cli/bb-convert)
3. Make use of the Mock Data Modules in the Model

    > **NOTE:**
    > The following snippets are examples of how to consume mock data.

    - Import Mock Data Module in the Model

            :::javascript
            import dataProviderAdvisorsKey,
                { advisorsDataKey } from 'data-bb-advisors-http-ng';
            ...

    - Inject the Mock Data Module as a dependency

            :::javascript
            .module(moduleKey, [ 
                dataProviderAdvisorsKey,
            ...

    - Inject the Provider as a dependency in the Model Factory

    	    :::javascript
            '$q',
            advisorsDataKey,
            ...

  	- Declare as argument inside the factory

  		    :::javascript
  		    export default function appointmentsModel(Promise, AdvisorsData, ...

  	- Implement methods in the Model

   	    	:::javascript
            let getAdvisors = () => {
                return AdvisorsData
                    .getAdvisors()
                    .then(response => response.data);
            }
            ...

4. Load the Mock Data in the Widget Core on initialization
		
        :::javascript
        model
            .getAdvisors()
            .then(advisors => {
                $ctrl.advisors = advisors;
            });
        ...

5. Create the template to display the appointments according to the example

---

[< Back to exercises index](https://bitbucket.org/backbase/cxp-fe2-m00-training-overview)