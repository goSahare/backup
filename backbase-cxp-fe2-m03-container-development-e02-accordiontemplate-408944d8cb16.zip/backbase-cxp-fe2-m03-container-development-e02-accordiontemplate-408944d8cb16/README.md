# CXP Developer Essentials Frontend

## Module 03 - Exercise 02 : Improving the container template

### Objectives:
1. Implement a three panels accordion.
2. You must place a container's area inside of each panel. The first panel must be open by default
3. Make sure there is a title for each area (configurable via a preference)
4. When clicking the title, the specific area should become visible and the others should be hidden

## Implementing the accordion plugin in your container

### Import the accordion feature to your portal

An Accordion Plugin is provided for this exercise. Find the plugin in the vendor-training-accordion-js folder.

1. Copy the folder vendor-training-accordion-js to **statics/collection-training/prebuilt/**
2. Import your collection into the portal.
        

### Enable the accordion plugin for being used in the container

In order to use the accordion we must add the reference to the container's config.xml file.

> **Tip:** *In the following article you'll find all the information for concepts covered in this topic.*  
[How To Refer to Shared Resources Stored in a Feature](https://my.backbase.com/docs/product-documentation/documentation//portal/5.6.3/features_using.html)


## Add properties to manage accordion heading titles

We are going to set three widget preferences containing the section titles, and we will refer to these properties in the view.  
By doing this, we will achieve the requirement "Allow the business user to change the titles by using preferences"

1. Navigate to **statics/collection-training/prebuilt/container-training-accordion**
2. Open **model.xml** file and **add** the following properties **after** the last existing property node:

        :::xml
        <property label="First Section Title" name="firstSectionTitle" viewHint="manager,designModeOnly">
            <value type="string">First Section. (This title comes from the model)</value>
        </property>
        <property label="Second Section Title" name="secondSectionTitle" viewHint="manager,designModeOnly">
            <value type="string">Second Section. (This title comes from the model)</value>
        </property>
        <property label="Third Section Title" name="thirdSectionTitle" viewHint="manager,designModeOnly">
            <value type="string">Third Section. (This title comes from the model)</value>
        </property>


> **Note:** Don't forget to add the viewHint attribute if you want to allow the user to change properties values from the CXP Manager.
>
> Read the following article for more information: [How To Add Properties to a Widget](https://my.backbase.com/docs/product-documentation/documentation//portal/5.6.3/widgets_addproperties.html)

## Adding the accordion markup to the container template

1. Navigate to **statics/collection-training/prebuilt/template-container-training-accordion/templates**
2. Open **template-container-training-accordion.soy** file
3. Look for this div

        :::html
        <div class="bp-container template-container-training-accordion" data-pid="{$item.name}">


4. Replace its contents with the required backbase-js-accordion [markup](vendor-training-accordion-js/README.md) 

5. Replace static titles with the custom properties that contains section titles. *(Ex. First Section Title)*

6. Replace static content with an area placeholder. *(Ex. First Section Content)*:

## Container event handlers

Every container can listen to events. This will allow the developer to execute some code when an event is triggered.

> If you want to know the full list of supported events read the following article:  
[CXP Web Library - Events](https://my.backbase.com/docs/product-documentation/documentation//portal/5.7.0/events_widgetevents.html)

### Initializing your accordion with event handlers

1. Navigate to **statics/collection-training/prebuilt/container-training-accordion/scripts**
2. **Edit** the file **container-training-accordion.js**, so your container is initialized in the following event handlers:

  * DOMReady
  * preferencesSaved  
        
> Tip: Accordion can be initialized by ***new Accordion()***

## Testing your brand new Accordion Container

1. Open **your portal**
2. Go to your portal catalog.
2. Within the "Enterprise Catalog" section, search for **training accordion**
3. Click on it to add it to your portal
4. Go back to Page Management
5. Create a new page and name it "**Training Accordion**"
6. Drop your Training Accordion Container into that page
7. Click the accordion's first title and drop a structured content widget on the area that will be displayed below.
8. Repeat step **#7** for the accordion's second and third titles
9. Check it working in live mode
10. Go back to design mode, click Training Accordion Container settings icon
11. Look for Section Title fields and change its values
12. Go to live mode again
13. Check that the new titles are being displayed

---

[< Back to exercises index](https://bitbucket.org/backbase/cxp-fe2-m00-training-overview)